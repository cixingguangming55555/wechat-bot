#pragma once
wchar_t* wstring_to_wchar(const std::wstring &ws);
char* string_to_char(const std::string &ws);
std::string ucs2_to_utf8(wchar_t* pucs2);
std::wstring utf8_to_ucs2(char* p_utf8);
std::string WINAPI string_To_UTF8(const std::string &str);
std::string utf8_to_gbk(const std::string& str);
int WINAPI __OutputDebugString(LPCTSTR pstrFormat, ...);


#define C_OUTPUT_DEBUG_INFO 1 
