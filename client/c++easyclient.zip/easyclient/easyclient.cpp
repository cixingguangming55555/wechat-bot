﻿// easyclient.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include "json.hpp"

#define USER_LIST 5000
#define TXT_MSG 555
using json = nlohmann::json;
// Compile with:
// g++ -std=gnu++0x example-client-cpp11.cpp -o example-client-cpp11
#include "easywsclient.hpp"
//#include "easywsclient.cpp" // <-- include only if you don't want compile separately
#ifdef _WIN32
#pragma comment( lib, "ws2_32" )
#include <WinSock2.h>
#endif
#include <assert.h>
#include <stdio.h>
#include <string>
#include <memory>
#include <sstream>
#include <time.h>
#include<Windows.h>
#include "strlib.h"
using std::string;
using std::vector;
using std::wstring;
string WINAPI inttostring(int para)
{
	std::stringstream ss;
	ss << para;
	string r = ss.str();
	return r;
}
string WINAPI s_wxtime()
{
	struct tm t;
	time_t now;  //声明time_t类型变量
	time(&now);      //获取系统日期和时间
	localtime_s(&t, &now);   //获取当地日期和时间

	string year = inttostring(t.tm_year + 1900);
	string month = inttostring(t.tm_mon);
	string day = inttostring(t.tm_mday);
	string hour = inttostring(t.tm_hour);
	string min = inttostring(t.tm_min);
	string sec = inttostring(t.tm_sec);

	string format = year + month + day  + hour + min +  sec;
	return format;
}




/* 发送到服务端，获取用户列表
*/
string send_buffer(DWORD type,string wxid,string content) 
{
	json j;
	j["type"]= type;
	j["id"] = s_wxtime();
	j["wxid"] = wxid;
	j["content"] = content;

	string buf = j.dump();
	return buf;
}

void print_heart_msg(json j)
{
	string content = j["content"];
	content = utf8_to_gbk(content);
	printf("%s\n",content.c_str());
}
void print_user_list(json j)
{
	json data = j["content"];

	for (json::iterator it = data.begin(); it != data.end(); ++it)
	{
		json a = *it;
		string wxid = a["wxid"];
		string name = a["name"];
		wstring wname = utf8_to_ucs2(string_to_char(name));
		wstring wid   = utf8_to_ucs2(string_to_char(wxid));
		_wsetlocale(LC_ALL, L"chs");
		wprintf(TEXT("id:%s\n"), wid.c_str());
    	wprintf(TEXT("name:%s\n"),wname.c_str());
	}
}


void print_recv_msg(json j)
{
	string content = j["content"];
	string sender = j["sender"];
	string wxid = j["wxid"];

	content = utf8_to_gbk(content);
	printf("接收人:%s\n",wxid.c_str());
	printf("内容:%s\n", content.c_str());
	printf("发送人:%s\n",sender.c_str());
	

}

int main()
{
	using easywsclient::WebSocket;
#ifdef _WIN32
	INT rc;
	WSADATA wsaData;

	rc = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (rc) {
		printf("WSAStartup Failed.\n");
		return 1;
	}
#endif

	std::unique_ptr<WebSocket> ws(WebSocket::from_url("ws://localhost:5555"));
	assert(ws);
	//获取服务端通讯录好友数据,wxid,name
	//string user_list = send_buffer(USER_LIST,"null","user_list");
	//ws->send(user_list);
	//获取服务端通讯录好友数据,wxid,name

	//发送文本消息
	//string msg = string_To_UTF8("hello,欢迎使用本软件，有问题请联系1498814665@qq.com或加QQ，备注：机器人");
	//string txt_msg = send_buffer(TXT_MSG,"filehelper",msg);
	//ws->send(txt_msg);
	//发送文本消息

	while (ws->getReadyState() != WebSocket::CLOSED) {
		WebSocket::pointer wsp = &*ws; // <-- because a unique_ptr cannot be copied into a lambda
		ws->poll();
		ws->dispatch([wsp](const std::string & message) 
		{
			json j = json::parse(message);
			DWORD type = j["type"];
			switch (type) 
			{
			case 1://接收到的文本消息
				print_recv_msg(j);
				break;
			case 5005://心跳消息
				print_heart_msg(j);
				break;
			case 5001://
				print_user_list(j);
				break;
			case 5002:
				print_heart_msg(j);
				break;
			case 556://发送消息成功
				print_heart_msg(j);
				break;
			case 557://发送消息失败
				print_heart_msg(j);
				break;
			default:
				break;
			}

			//printf(">>> %s\n", message.c_str());
			if (message == "world") 
			{ wsp->close(); }
		});
	}
#ifdef _WIN32
	WSACleanup();
#endif
	// N.B. - unique_ptr will free the WebSocket instance upon return:
	return 0;
}

