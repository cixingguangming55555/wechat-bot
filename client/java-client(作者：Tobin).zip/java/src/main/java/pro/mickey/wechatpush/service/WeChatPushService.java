package pro.mickey.wechatpush.service;

import lombok.extern.slf4j.Slf4j;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.springframework.beans.factory.annotation.Value;
import pro.mickey.wechatpush.service.dto.WeChatMsgDTO;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;

@Slf4j
public class WeChatPushService extends WebSocketClient {
    @Value("${config.weChat.HEART_BEAT}")
    private Integer HEART_BEAT;
    @Value("${config.weChat.RECV_TXT_MSG}")
    private Integer RECV_TXT_MSG;
    @Value("${config.weChat.USER_LIST}")
    private Integer USER_LIST;
    @Value("${config.weChat.GET_USER_LIST_SUCCSESS}")
    private Integer GET_USER_LIST_SUCCSESS;
    @Value("${config.weChat.GET_USER_LIST_FAIL}")
    private Integer GET_USER_LIST_FAIL;
    @Value("${config.weChat.TXT_MSG}")
    private Integer TXT_MSG;
    @Value("${config.weChat.PIC_MSG}")
    private Integer PIC_MSG;
    @Value("${config.weChat.AT_MSG}")
    private Integer AT_MSG;
    @Value("${config.weChat.CHATROOM_MEMBER}")
    private Integer CHATROOM_MEMBER;
    @Value("${config.weChat.CHATROOM_MEMBER_NICK}")
    private Integer CHATROOM_MEMBER_NICK;
    @Value("${config.weChat.PERSONAL_INFO}")
    private Integer PERSONAL_INFO;
    @Value("${config.weChat.DEBUG_SWITCH}")
    private Integer DEBUG_SWITCH;
    @Value("${config.weChat.PERSONAL_DETAIL}")
    private Integer PERSONAL_DETAIL;

    public WeChatPushService(String url) throws URISyntaxException {
        super(new URI(url));
    }

    @Override
    public void onOpen(ServerHandshake serverHandshake) {
        log.info("正在打开链接....");
    }

    @Override
    public void onMessage(String s) {
        log.info("收到消息：" + s);
    }

    @Override
    public void onClose(int i, String s, boolean b) {
        log.info("关闭链接");
    }

    @Override
    public void onError(Exception e) {
        log.info("异常");
    }

    /**
     * 获取消息ID
     * @return
     */
    private String getId(){
     return String.valueOf(new Date().getTime());
    }
    /**
     * 发送文字消息
     * @param WxId
     * @param text
     */
    public void sendMsg(String WxId, String text) {
        String id = getId();
        String json = WeChatMsgDTO.builder()
                .content(text)
                .wxid(WxId)
                .type(TXT_MSG)
                .id(id)
                .build()
                .toJson();
        //log.info("sendMsg:" + json);
        sendMsg(json);
    }

    /**
     * 获取联系人信息
     */
    public void getContact() {
        String id = getId();
        String json = WeChatMsgDTO.builder()
                .content("user list")
                .wxid("ROOT")
                .type(USER_LIST)
                .id(id)
                .build()
                .toJson();
        //log.info("getContact:" + json);
        sendMsg(json);
    }

    /**
     * 发送
     * @param json
     */
    private void sendMsg(String json) {
        try {
            send(json);
        } catch (Exception e) {
            /**
             * 这块我本来用于发送微信失败补偿邮件
             */
        }
    }

    /**
     * 获取群用户信息，不传群组ID为全部群，
     * @param WxId
     */
    public void getChatRoomMemers(String WxId){
        String id = getId();
        Integer type = (WxId.equals(""))?CHATROOM_MEMBER:CHATROOM_MEMBER_NICK;
        String wxid = (WxId.equals(""))?"ROOT":WxId;
        String json = WeChatMsgDTO.builder()
                .content("op:list member")
                .wxid("ROOT")
                .type(type)
                .id(id)
                .build()
                .toJson();
        //log.info("getContact:" + json);
        sendMsg(json);
    }
}
