package pro.mickey.wechatpush.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class TestService {

    @Autowired
    private WeChatPushService weChatService;

    @Scheduled(fixedRate = 1000 * 60 * 10)
    public void showNews() {
        //获取联系人
        weChatService.getContact();
        //发送消息
        weChatService.sendMsg("", "你好，现在的时间是："+String.valueOf(new Date().getTime()));
        //获取群组用户
        weChatService.getChatRoomMemers("");
    }
}
